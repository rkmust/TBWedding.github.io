(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('tb-' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('tb-' + k, JSON.stringify(v)); } catch (e) {} }
  };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  // All times are Pacific Standard Time (UTC-8) for Nov 13-15, 2026.
  function at(day, hm) { return new Date('2026-11-' + day + 'T' + hm + ':00-08:00').getTime(); }

  var SHUTTLE_PRIVATE = ['bird', 'cedar', 'mesa', 'warner'];
  var STAYS = [
    ['fairfield', 'Fairfield Inn'], ['bird', 'Bird House'], ['cedar', 'Cedar House'],
    ['mesa', 'Mesa Silverado'], ['warner', 'Warner House'], ['venue', 'Glass / Stone House'],
    ['wolves', 'Wolves Ranch'], ['other', 'Somewhere else']
  ];
  var VENUE = 'Main venue (Glass House + Stone House)';

  var DAYS = [
    { id: '13', name: 'Fri', date: 'Nov 13', note: '' },
    { id: '14', name: 'Sat', date: 'Nov 14', note: 'There is plenty to explore in Joshua Tree, and you are welcome to relax on the property all weekend.' },
    { id: '15', name: 'Sun', date: 'Nov 15', note: 'All guests are welcome at brunch.' }
  ];

  var EVENTS = [
    { d: '13', s: '17:45', e: '19:00', t: '5:45 PM', n: 'Rehearsal dinner', p: 'Bird House', x: 'Private dinner for invited guests.', priv: true },
    { d: '13', s: '18:00', e: '20:00', t: '6:00 PM', u: 'to 8:00', n: 'Welcome party', p: 'Glass House', x: 'Food truck dinner, pay by guest. All guests welcome. Bri, Tas and the rehearsal guests join around 7 PM.' },
    { d: '13', s: '20:00', e: '22:00', t: '8:00 PM', u: 'to 10:00', n: 'Live band', p: 'Glass House', x: '' },
    { d: '14', s: '09:00', e: '11:00', t: '9:00 AM', u: 'to 11:00', n: 'Brunch food truck', p: 'Glass House', x: 'Pay by guest.' },
    { d: '14', s: '11:00', e: '13:25', t: 'Midday', n: 'Free time on the property', p: 'Pools, trails, skate bowl', x: 'Pools, daybeds, trampoline, fire pits, pool table and the hiking trail are open to all guests.' },
    { d: '14', s: '13:25', e: '14:15', t: '1:25 PM', u: 'to 2:15', n: 'Shuttle pick ups', p: 'Cedar, Bird, Mesa Silverado, Warner', x: 'Privately coordinated. Your exact time arrives by Friday.', ride: 'private' },
    { d: '14', s: '13:45', e: '14:15', t: '1:45 PM', n: 'Shuttle pick up', p: 'Fairfield Inn', x: 'Be in the lobby a few minutes early.', ride: 'fairfield' },
    { d: '14', s: '14:30', e: '15:00', t: '2:30 PM', n: 'Guest arrivals', p: VENUE, x: '' },
    { d: '14', s: '15:00', e: '17:00', t: '3:00 PM', n: 'Ceremony begins', p: VENUE, x: '' },
    { d: '14', s: '17:00', e: '22:00', t: '5:00 PM', n: 'Reception dinner', p: VENUE, x: 'Return shuttle service is available to all guests.' },
    { d: '15', s: '09:00', e: '11:00', t: '9:00 AM', u: 'to 11:00', n: 'Brunch truck', p: 'Glass House', x: 'Pay by guest. All guests are welcome.' },
    { d: '15', s: '13:00', e: '13:30', t: '1:00 PM', n: 'Check out', p: 'All houses', x: '' }
  ];
  EVENTS.forEach(function (ev) { ev.start = at(ev.d, ev.s); ev.end = at(ev.d, ev.e); });

  var DESTS = {
    venue: {
      label: 'Venue', sub: 'Glass + Stone', title: 'Main venue', detail: 'Glass House + Stone House',
      addr: '80053 Indian Trail, Twentynine Palms, CA 92277',
      from: 'From Twentynine Palms Highway, heading east',
      steps: [
        ['Turn left onto Godwin Rd', ''],
        ['Continue past Amboy Rd', 'The paved road turns to dirt at Amboy Rd. Keep going.'],
        ['Turn right onto Valle Vista Rd', 'Look for the A-frame sign with the T⚡B logo. Do not turn early at Ward Lane, Leaches, Tony Rd, Mortiz or Pipeline.'],
        ['Turn right onto Gayley Ln', 'You are now heading south.'],
        ['Turn left onto Indian Trail Dr', 'Look for the A-frame sign with the T⚡B logo. Drive through the entrance gates until you see the property.']
      ]
    },
    bird: {
      label: 'Bird', sub: 'House', title: 'Bird House', detail: 'Friday rehearsal dinner',
      addr: '3966 Steeg Rd, Twentynine Palms, CA 92277',
      from: 'From Twentynine Palms Highway, heading east',
      steps: [
        ['Turn left onto Godwin Rd', ''],
        ['Turn right onto Amboy Rd', ''],
        ['Turn left onto Steeg Rd', 'The dirt roads start here.'],
        ['At the fork, turn left onto Mesa Dr', ''],
        ['Drive past the orange house', 'Keep going until you see three tires.'],
        ['Turn right onto Steeg Rd at the tires', 'This brings you to the Bird House.']
      ]
    },
    cedar: {
      label: 'Cedar', sub: 'House', title: 'Cedar House', detail: 'Five-minute drive from Stone House',
      addr: '',
      from: 'From Amboy Rd',
      steps: [
        ['Turn left off Amboy Rd onto Blower Rd', 'Coming from Vegas or Phoenix, this is a right turn.'],
        ['Continue on Blower Rd', 'Keep going until you see Cedar House on your left.']
      ]
    }
  };

  var CHECK = [
    'Download the offline map of the area in Google or Apple Maps',
    'Open this app and leave it open before you lose service',
    'Read the directions for your first stop once, start to finish',
    'Have a way to pay at the food trucks',
    'Pack bikes, e-bikes or other gear if you want them',
    'Confirm your shuttle time if you are at Cedar, Bird, Mesa Silverado or Warner'
  ];
  var AMEN = ['Pools', 'Daybeds', 'Trampoline', 'Fire pits', 'Pool table', 'Hiking trail to the mountain', 'Deeper skate bowl'];

  /* ---------- navigation ---------- */
  var VIEWS = ['now', 'schedule', 'drive', 'maps', 'guide'];
  function show(v) {
    if (VIEWS.indexOf(v) < 0) v = 'now';
    VIEWS.forEach(function (id) { $('v-' + id).classList.toggle('on', id === v); });
    Array.prototype.forEach.call(document.querySelectorAll('nav button'), function (b) {
      if (b.dataset.v === v) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    $('main').scrollTop = 0;
  }
  function go(v) { try { location.hash = v; } catch (e) {} show(v); }
  document.querySelector('nav').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (b) go(b.dataset.v);
  });
  window.addEventListener('hashchange', function () { show(location.hash.slice(1)); });

  /* ---------- stay + ride ---------- */
  var stay = store.get('stay', null);
  function rideText() {
    if (!stay) return '';
    if (stay === 'fairfield') return 'Your shuttle leaves the Fairfield Inn at <strong>1:45 PM</strong> on Saturday. A return shuttle brings you back.';
    if (SHUTTLE_PRIVATE.indexOf(stay) >= 0) return 'Your shuttle picks up between <strong>1:25 and 2:15 PM</strong> on Saturday. Your exact time arrives privately by Friday. A return shuttle brings you back.';
    if (stay === 'venue') return 'You are already at the main venue. Guest arrivals start at <strong>2:30 PM</strong> on Saturday.';
    return 'There is no shuttle to the venue from your stay. Drive to the main venue for <strong>2:30 PM</strong> arrivals. The return shuttle is available to all guests.';
  }
  function isMyRide(ev) {
    if (!ev.ride) return false;
    return (ev.ride === 'fairfield' && stay === 'fairfield') || (ev.ride === 'private' && SHUTTLE_PRIVATE.indexOf(stay) >= 0);
  }
  function relevant(ev) { return !ev.ride || !stay || isMyRide(ev); }
  function renderStay() {
    $('stay').innerHTML = STAYS.map(function (s) {
      return '<button class="chip" data-s="' + s[0] + '" aria-pressed="' + (stay === s[0]) + '">' + esc(s[1]) + '</button>';
    }).join('');
    $('ride').innerHTML = rideText();
  }
  $('stay').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    stay = stay === b.dataset.s ? null : b.dataset.s;
    store.set('stay', stay); renderStay(); renderNow(); renderDay();
  });

  /* ---------- now ---------- */
  function fmtLeft(ms) {
    var m = Math.max(0, Math.ceil(ms / 60000));
    var d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), mm = m % 60;
    if (d > 0) return d + 'd ' + h + 'h';
    if (h > 0) return h + 'h ' + (mm < 10 ? '0' : '') + mm + 'm';
    return mm + ' min';
  }
  function dayName(ev) { return { '13': 'Friday', '14': 'Saturday', '15': 'Sunday' }[ev.d]; }
  function renderNow() {
    var now = Date.now();
    var list = EVENTS.filter(function (ev) { return relevant(ev) && !ev.priv; });
    var live = list.filter(function (ev) { return ev.start <= now && now < ev.end; });
    var coming = list.filter(function (ev) { return ev.start > now; });
    var hero = $('hero'), up = $('upnext');
    var cur = live[live.length - 1], nxt = coming[0];
    if (cur) {
      hero.className = 'hero live';
      hero.innerHTML = '<div class="eyebrow">Happening now</div><h1>' + esc(cur.n) + '</h1><p>' + esc(cur.p) + '</p>' + (cur.x ? '<p class="small">' + esc(cur.x) + '</p>' : '');
    } else if (nxt) {
      hero.className = 'hero';
      hero.innerHTML = '<div class="eyebrow">' + esc(nxt.n) + ' starts in</div><div class="count">' + fmtLeft(nxt.start - now) + '</div><p>' + dayName(nxt) + ' at ' + nxt.t + ' · ' + esc(nxt.p) + '</p>';
    } else {
      hero.className = 'hero';
      hero.innerHTML = '<div class="eyebrow">That is a wrap</div><h1>Safe travels home</h1><p>Thank you for celebrating Bri and Tas.</p>';
    }
    var after = cur ? nxt : coming[1];
    if (after) {
      up.style.display = '';
      up.innerHTML = '<div class="eyebrow">' + (cur ? 'Up next' : 'After that') + '</div><div class="ev" style="padding:0;border:0;background:none"><div class="t">' + after.t + '<small>' + dayName(after) + '</small></div><div class="b"><div class="n">' + esc(after.n) + '</div><div class="p">' + esc(after.p) + '</div></div></div>' +
        '<div class="row"><button class="btn" data-go="schedule">Full schedule</button><button class="btn primary" data-go="drive">Get directions</button></div>';
    } else {
      up.style.display = 'none';
    }
  }
  $('upnext').addEventListener('click', function (e) { var b = e.target.closest('[data-go]'); if (b) go(b.dataset.go); });

  /* ---------- schedule ---------- */
  function todayPT() {
    try { return new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }).slice(8, 10); } catch (e) { return '13'; }
  }
  var day = (function () { var t = todayPT(), ok = Date.now() > at('13', '00:00') && Date.now() < at('15', '23:59'); return ok && (t === '13' || t === '14' || t === '15') ? t : '13'; })();
  function renderDay() {
    $('days').innerHTML = DAYS.map(function (d) {
      return '<button data-d="' + d.id + '" aria-pressed="' + (d.id === day) + '">' + d.name + '<span>' + d.date + '</span></button>';
    }).join('');
    var D = DAYS.filter(function (d) { return d.id === day; })[0];
    $('daynote').textContent = D.note; $('daynote').style.display = D.note ? '' : 'none';
    var now = Date.now();
    var firstNext = EVENTS.filter(function (ev) { return relevant(ev) && !ev.priv && ev.start > now; })[0];
    $('timeline').innerHTML = EVENTS.filter(function (ev) { return ev.d === day && relevant(ev); }).map(function (ev) {
      var tags = '';
      if (ev.start <= now && now < ev.end) tags += '<span class="tag now">Now</span>';
      else if (ev === firstNext) tags += '<span class="tag next">Next</span>';
      if (isMyRide(ev)) tags += '<span class="tag you">Your ride</span>';
      if (ev.priv) tags += '<span class="tag priv">Invited guests</span>';
      return '<div class="ev' + (now >= ev.end ? ' past' : '') + '"><div class="t">' + ev.t + (ev.u ? '<small>' + ev.u + '</small>' : '') + '</div><div class="b">' +
        (tags ? '<div class="row" style="gap:6px">' + tags + '</div>' : '') +
        '<div class="n">' + esc(ev.n) + '</div><div class="p">' + esc(ev.p) + '</div>' + (ev.x ? '<div class="small">' + esc(ev.x) + '</div>' : '') + '</div></div>';
    }).join('');
  }
  $('days').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) { day = b.dataset.d; renderDay(); } });

  /* ---------- directions ---------- */
  var dest = store.get('dest', 'venue'); if (!DESTS[dest]) dest = 'venue';
  var done = store.get('done', {});
  function mapsUrl(a, apple) { var q = encodeURIComponent(a); return apple ? 'https://maps.apple.com/?q=' + q : 'https://www.google.com/maps/search/?api=1&query=' + q; }
  function renderDest() {
    $('dests').innerHTML = Object.keys(DESTS).map(function (k) {
      return '<button data-k="' + k + '" aria-pressed="' + (k === dest) + '">' + DESTS[k].label + '<span>' + DESTS[k].sub + '</span></button>';
    }).join('');
    var D = DESTS[dest];
    var h = '<div class="eyebrow">' + esc(D.detail) + '</div><h3>' + esc(D.title) + '</h3>';
    if (D.addr) {
      h += '<p class="addr">' + esc(D.addr) + '</p><div class="row"><a class="btn" href="' + mapsUrl(D.addr) + '" target="_blank" rel="noopener">Google Maps</a><a class="btn" href="' + mapsUrl(D.addr, true) + '" target="_blank" rel="noopener">Apple Maps</a><button class="btn" id="copyaddr">Copy address</button></div><p class="small muted">GPS may send you down the wrong roads. Follow the steps below for the final stretch.</p>';
    } else {
      h += '<p class="small muted">No street address was shared for Cedar House. Follow the steps below and check the road map.</p>';
    }
    $('destcard').innerHTML = h;
    $('fromline').textContent = D.from;
    var dn = done[dest] || [];
    $('steps').innerHTML = D.steps.map(function (s, i) {
      return '<li><button data-i="' + i + '" aria-pressed="' + (dn.indexOf(i) >= 0) + '"><span class="st">' + esc(s[0]) + (s[1] ? '<span class="sn">' + esc(s[1]) + '</span>' : '') + '</span></button></li>';
    }).join('');
  }
  $('dests').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) { dest = b.dataset.k; store.set('dest', dest); renderDest(); } });
  $('steps').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    var i = +b.dataset.i, dn = done[dest] || [], at = dn.indexOf(i);
    if (at >= 0) dn.splice(at, 1); else dn.push(i);
    done[dest] = dn; store.set('done', done); renderDest();
  });
  $('resetsteps').addEventListener('click', function () { done[dest] = []; store.set('done', done); renderDest(); });
  $('destcard').addEventListener('click', function (e) {
    if (!e.target.closest('#copyaddr')) return;
    var a = DESTS[dest].addr;
    try { navigator.clipboard.writeText(a).then(function () { toast('Address copied'); }, function () { toast('Copy did not work. Press and hold the address.'); }); }
    catch (err) { toast('Copy did not work. Press and hold the address.'); }
  });
  var tt;
  function toast(m) { var t = $('toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('on'); }, 2200); }

  /* ---------- maps ---------- */
  var MAPS = {
    roads: { src: 'maps/roads.jpg', alt: 'Road map showing the routes to Glass House, Stone House, Cedar House and Bird House', cap: 'Rust lines are the safe routes. Yellow pins mark Glass House, Stone House, Cedar House, Bird House and the Mesa Silverado and Wolves Ranch Airbnbs.' },
    property: { src: 'maps/property.jpg', alt: 'Property map of Nowhere California showing Cedar House, Stone House, Stone Suites, Glass House, Bird House and Swallow House', cap: 'Not to scale. The skate plaza and bowl sit between Glass House and Stone House. The pool is at Stone House, and Mount Wonder is behind it.' }
  };
  function setMap(k) {
    $('mapimg').src = MAPS[k].src; $('mapimg').alt = MAPS[k].alt; $('mapcap').textContent = MAPS[k].cap;
    Array.prototype.forEach.call($('mapsel').children, function (b) { b.setAttribute('aria-pressed', String(b.dataset.map === k)); });
    zoom(false);
  }
  function zoom(on) {
    var box = $('mapbox'); box.classList.toggle('zoom', on);
    $('zoombtn').textContent = on ? 'Zoom out' : 'Zoom in';
    if (on) setTimeout(function () { box.scrollLeft = (box.scrollWidth - box.clientWidth) / 2; box.scrollTop = (box.scrollHeight - box.clientHeight) / 2; }, 220);
  }
  $('mapsel').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) setMap(b.dataset.map); });
  $('zoombtn').addEventListener('click', function () { zoom(!$('mapbox').classList.contains('zoom')); });
  $('mapimg').addEventListener('click', function () { zoom(!$('mapbox').classList.contains('zoom')); });

  /* ---------- guide ---------- */
  var checked = store.get('check', []);
  $('amen').innerHTML = AMEN.map(function (a) { return '<span class="chip" style="min-height:0">' + esc(a) + '</span>'; }).join('');
  $('check').innerHTML = CHECK.map(function (c, i) {
    return '<li><label for="ck' + i + '"><input type="checkbox" id="ck' + i + '" data-i="' + i + '"' + (checked.indexOf(i) >= 0 ? ' checked' : '') + '><span>' + esc(c) + '</span></label></li>';
  }).join('');
  $('check').addEventListener('change', function (e) {
    var i = +e.target.dataset.i, at = checked.indexOf(i);
    if (e.target.checked && at < 0) checked.push(i); if (!e.target.checked && at >= 0) checked.splice(at, 1);
    store.set('check', checked);
  });

  /* ---------- boot ---------- */
  renderStay(); renderNow(); renderDay(); renderDest(); setMap('roads');
  show(location.hash.slice(1) || 'now');
  setInterval(function () { renderNow(); renderDay(); }, 30000);
})();
